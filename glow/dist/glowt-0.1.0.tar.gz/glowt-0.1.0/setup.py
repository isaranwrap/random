from setuptools import setup

setup(
	name = "glowt",
	version = "0.1.0",
	description = "Create colorful glowing graphs!",
	py_modules=["glowt"],
	package_dir = {'':'src'},
)
